"""
py2app 打包配置文件
用于将股票交易系统打包成 macOS App
"""

from setuptools import setup

APP_NAME = 'StockTrader'
APP_VERSION = '1.0'
APP = 'app.py'

# 读取依赖
with open('../requirements.txt') as f:
    REQUIREMENTS = [line.strip() for line in f if line.strip() and not line.startswith('#')]

# 添加 tkinter (Python内置)
if 'tkinter' not in REQUIREMENTS:
    REQUIREMENTS.append('tkinter')

setup(
    app=[
        {
            'script': APP,
            'iconfile': 'icon.icns',  # 可选: App图标
        },
    ],
    name=APP_NAME,
    version=APP_VERSION,
    description='股票自动交易系统',
    author='StockTrader',
    author_email='',
    url='',
    options={
        'py2app': {
            'argv_emulation': True,
            'includes': [
                'tkinter',
                'tkinter.ttk',
                'tkinter.scrolledtext',
            ],
            'excludes': [
                'matplotlib',
                'numpy',
                'pandas',
                'scipy',
            ],
            'optimize': 2,
            'frameworks': [],
            'resources': [
                'data',
                'logs',
            ],
            'plist': {
                'CFBundleName': APP_NAME,
                'CFBundleDisplayName': '股票自动交易',
                'CFBundleIdentifier': 'com.stocktrader.app',
                'CFBundleVersion': APP_VERSION,
                'CFBundleShortVersionString': APP_VERSION,
                'CFBundlePackageType': 'APPL',
                'CFBundleExecutable': APP_NAME,
                'LSMinimumSystemVersion': '10.13',
                'LSUIElement': False,
                'NSPrincipalClass': 'NSApplication',
                'NSHighResolutionCapable': True,
            },
        },
    },
    setup_requires=['py2app'],
    install_requires=REQUIREMENTS,
)
